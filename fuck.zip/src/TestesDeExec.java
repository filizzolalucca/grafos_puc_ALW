import java.util.Random;

public class TestesDeExec {
    public static void main(String[] args) {
        int[] tamanhos = {10, 100, 1000, 10000, 100000, 1000000 };

        for (int tamanho : tamanhos) {
            GrafoMatrizAdjacencia grafo_Positivo = criarGrafoAleatorioSemValorNegativo(tamanho);
            GrafoMatrizAdjacencia grafoAleatorio = criarGrafoAleatorio(tamanho);

            System.out.println("------------------- Dijkstra --------------------------");
            // Medindo o tempo para o método de caminho mínimo para todos os vértices Djikstra
            long startTime = System.currentTimeMillis();
            grafo_Positivo.dijkstraMenorDistanciaTodosParaTodos();
            long endTime = System.currentTimeMillis();

            long tempoExecucao = endTime - startTime;
            System.out.println("Tempo de execução para " + tamanho + " vértices: " + tempoExecucao + " ms");

            System.out.println("------------------- Bellman Ford --------------------------");
            // Medindo o tempo para o método de caminho mínimo para todos os vértices Bellman-Ford
            startTime = System.currentTimeMillis();
            grafoAleatorio.bellmanFordMenorDistanciaTodosParaTodos();
            endTime = System.currentTimeMillis();

            tempoExecucao = endTime - startTime;
            System.out.println("Tempo de execução para " + tamanho + " vértices: " + tempoExecucao + " ms");

            System.out.println("------------------- Floyd Warshall --------------------------");
            // Medindo o tempo para o método de caminho mínimo para todos os vértices Bellman-Ford
            startTime = System.currentTimeMillis();
            grafoAleatorio.floydWarshall();
            endTime = System.currentTimeMillis();

            tempoExecucao = endTime - startTime;
            System.out.println("Tempo de execução para " + tamanho + " vértices: " + tempoExecucao + " ms");

        }
    }

    private static GrafoMatrizAdjacencia criarGrafoAleatorio(int tamanho) {
        GrafoMatrizAdjacencia grafo = new GrafoMatrizAdjacencia(tamanho, true);
        Random random = new Random();

        // Adicionando arestas aleatórias com pesos negativos
        for (int i = 0; i < tamanho - 1; i++) {
            int verticeOrigem = i;
            int verticeDestino = i + 1;
            int peso = random.nextInt(21) - 10; // Peso variando de -10 a 10

            grafo.inserirAresta(verticeOrigem, verticeDestino, peso);
        }

        // Adicionando uma aresta do último vértice para o primeiro para garantir que o
        // grafo seja conexo
        int peso = random.nextInt(21) - 10;
        grafo.inserirAresta(tamanho - 1, 0, peso);

        return grafo;
    }

    private static GrafoMatrizAdjacencia criarGrafoAleatorioSemValorNegativo(int tamanho) {
        GrafoMatrizAdjacencia grafo = new GrafoMatrizAdjacencia(tamanho, true);
        Random random = new Random();

        // Adicionando arestas aleatórias com pesos positivos
        for (int i = 0; i < tamanho - 1; i++) {
            int verticeOrigem = i;
            int verticeDestino = i + 1;
            int peso = random.nextInt(21); // Peso variando de 0 a 20

            grafo.inserirAresta(verticeOrigem, verticeDestino, peso);
        }

        // Adicionando uma aresta do último vértice para o primeiro para garantir que o
        // grafo seja conexo
        int peso = random.nextInt(21); // Peso variando de 0 a 20
        grafo.inserirAresta(tamanho - 1, 0, peso);

        return grafo;
    }
}